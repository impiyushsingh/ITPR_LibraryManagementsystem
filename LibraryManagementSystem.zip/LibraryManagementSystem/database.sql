-- AUTHORS
CREATE TABLE authors (
    author_id INT AUTO_INCREMENT PRIMARY KEY,
    author_name VARCHAR(100) NOT NULL,
    biography TEXT
);

-- CATEGORIES
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL
);

-- RACKS
CREATE TABLE racks (
    rack_id INT AUTO_INCREMENT PRIMARY KEY,
    rack_number VARCHAR(20),
    section VARCHAR(50)
);

-- MEMBERS
CREATE TABLE members (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    mobile VARCHAR(15),
    membership_date DATE,
    membership_status VARCHAR(20),
    address VARCHAR(255)
);

-- STAFF
CREATE TABLE staff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    role VARCHAR(30),
    username VARCHAR(40) UNIQUE,
    password VARCHAR(40)
);

-- BOOKS
CREATE TABLE books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200),
    author_id INT,
    category_id INT,
    isbn VARCHAR(30),
    edition VARCHAR(30),
    publication_year INT,
    rack_id INT,
    total_copies INT,
    available_copies INT,
    lost_copies INT DEFAULT 0,

    CONSTRAINT fk_books_author FOREIGN KEY (author_id) REFERENCES authors(author_id),
    CONSTRAINT fk_books_category FOREIGN KEY (category_id) REFERENCES categories(category_id),
    CONSTRAINT fk_books_rack FOREIGN KEY (rack_id) REFERENCES racks(rack_id)
);

-- ISSUES
CREATE TABLE issues (
    issue_id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT,
    member_id INT,
    issue_date DATE,
    due_date DATE,
    return_date DATE,
    status VARCHAR(20),

    FOREIGN KEY (book_id) REFERENCES books(book_id),
    FOREIGN KEY (member_id) REFERENCES members(member_id)
);

-- FINES
CREATE TABLE fines (
    fine_id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT,
    issue_id INT,
    amount DECIMAL(10,2),
    status VARCHAR(20),
    payment_date DATE,

    FOREIGN KEY (member_id) REFERENCES members(member_id),
    FOREIGN KEY (issue_id) REFERENCES issues(issue_id)
);

-- REQUESTS
CREATE TABLE book_requests (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT,
    book_id INT,
    request_type VARCHAR(20),
    request_date DATE,
    status VARCHAR(20),

    FOREIGN KEY (member_id) REFERENCES members(member_id),
    FOREIGN KEY (book_id) REFERENCES books(book_id)
);

-- NOTIFICATIONS
CREATE TABLE notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT,
    message TEXT,
    type VARCHAR(30),
    status VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (member_id) REFERENCES members(member_id)
);

-- ALERTS
CREATE TABLE alerts (
    alert_id INT AUTO_INCREMENT PRIMARY KEY,
    alert_type VARCHAR(50),
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_read BOOLEAN DEFAULT FALSE
);

-- PURCHASES
CREATE TABLE purchases (
    purchase_id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT,
    vendor_id INT,
    quantity INT,
    purchase_date DATE,
    price_per_copy DECIMAL(10,2),

    FOREIGN KEY (book_id) REFERENCES books(book_id)
);

-- DAMAGED / LOST
CREATE TABLE damaged_books (
    damage_id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT,
    type VARCHAR(20),
    date DATE,
    remarks VARCHAR(100),

    FOREIGN KEY (book_id) REFERENCES books(book_id)
);
