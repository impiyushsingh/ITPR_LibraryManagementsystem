package lms.model;
import java.time.LocalDate;

public class Purchase {
    private int purchaseId;
    private int bookId;
    private int vendorId;
    private int quantity;
    private LocalDate purchaseDate;
    private double pricePerCopy;

    public Purchase(int id, int b, int v, int q, LocalDate d, double p) {
        purchaseId = id; bookId = b; vendorId = v;
        quantity = q; purchaseDate = d; pricePerCopy = p;
    }

    public Purchase(int b, int v, int q, LocalDate d, double p) {
        bookId = b; vendorId = v; quantity = q; purchaseDate = d; pricePerCopy = p;
    }

    public int getBookId() { return bookId; }
    public int getVendorId() { return vendorId; }
    public int getQuantity() { return quantity; }
    public LocalDate getPurchaseDate() { return purchaseDate; }
    public double getPricePerCopy() { return pricePerCopy; }
}
