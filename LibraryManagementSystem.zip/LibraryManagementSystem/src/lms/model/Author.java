package lms.model;

public class Author {
    private int authorId;
    private String authorName;
    private String biography;

    public Author(int id, String n, String b) {
        authorId = id; authorName = n; biography = b;
    }
    public Author(String n) { authorName = n; }

    public int getAuthorId() { return authorId; }
    public String getAuthorName() { return authorName; }
}
