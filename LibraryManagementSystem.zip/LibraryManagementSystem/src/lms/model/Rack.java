package lms.model;

public class Rack {
    private int rackId;
    private String rackNumber;
    private String section;

    public Rack(int r, String n, String s) {
        rackId = r; rackNumber = n; section = s;
    }

    public Rack(String n, String s) {
        rackNumber = n; section = s;
    }

    public String getRackNumber() { return rackNumber; }
    public String getSection() { return section; }
}
