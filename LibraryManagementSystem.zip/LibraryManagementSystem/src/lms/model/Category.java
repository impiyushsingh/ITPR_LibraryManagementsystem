package lms.model;

public class Category {
    private int categoryId;
    private String categoryName;

    public Category(int id, String n) { categoryId = id; categoryName = n; }
    public Category(String n) { categoryName = n; }

    public int getCategoryId() { return categoryId; }
    public String getCategoryName() { return categoryName; }
}
