package lms.model;

public class Book {
    private int bookId;
    private String title;
    private int authorId;
    private int categoryId;
    private String isbn;
    private String edition;
    private int publicationYear;
    private int rackId;
    private int totalCopies;
    private int availableCopies;
    private int lostCopies;

    public Book(int id, String t, int a, int c, String i, String e, int y, int r, int tot, int av, int lost) {
        bookId = id; title = t; authorId = a; categoryId = c; isbn = i;
        edition = e; publicationYear = y; rackId = r;
        totalCopies = tot; availableCopies = av; lostCopies = lost;
    }

    public Book(String t, int a, int c, String i, String e, int y, int r, int copies) {
        this(0, t, a, c, i, e, y, r, copies, copies, 0);
    }

    public int getBookId() { return bookId; }
    public String getTitle() { return title; }
    public int getAuthorId() { return authorId; }
    public int getCategoryId() { return categoryId; }
    public String getIsbn() { return isbn; }
    public String getEdition() { return edition; }
    public int getPublicationYear() { return publicationYear; }
    public int getRackId() { return rackId; }
    public int getTotalCopies() { return totalCopies; }
    public int getAvailableCopies() { return availableCopies; }
    public int getLostCopies() { return lostCopies; }
}
