package lms.model;
import java.sql.Date;

public class Fine {
    private int fineId;
    private int memberId;
    private int issueId;
    private double amount;
    private String status;
    private Date paymentDate;

    public Fine(int f, int m, int i, double a, String s, Date d) {
        fineId = f; memberId = m; issueId = i; amount = a; status = s; paymentDate = d;
    }
    public Fine(int m, int i, double a) { memberId = m; issueId = i; amount = a; }

    public int getMemberId() { return memberId; }
    public int getIssueId() { return issueId; }
    public double getAmount() { return amount; }
}
