package lms.model;
import java.time.LocalDate;

public class Damage {
    private int damageId;
    private int bookId;
    private String type;
    private LocalDate date;
    private String remarks;

    public Damage(int id, int b, String t, LocalDate d, String r) {
        damageId = id; bookId = b; type = t; date = d; remarks = r;
    }
    public Damage(int b, String t, LocalDate d, String r) {
        bookId = b; type = t; date = d; remarks = r;
    }

    public int getBookId() { return bookId; }
    public String getType() { return type; }
    public LocalDate getDate() { return date; }
    public String getRemarks() { return remarks; }
}
