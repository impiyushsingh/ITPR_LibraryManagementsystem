package lms.model;
import java.sql.Timestamp;

public class Notification {
    private int id;
    private int memberId;
    private String message;
    private String type;
    private String status;
    private Timestamp createdAt;

    public Notification(int i, int m, String msg, String t, String s, Timestamp c) {
        id = i; memberId = m; message = msg; type = t; status = s; createdAt = c;
    }

    public Notification(int m, String msg, String t) {
        memberId = m; message = msg; type = t;
    }

    public int getMemberId() { return memberId; }
    public String getMessage() { return message; }
    public String getType() { return type; }
}
