package lms.model;

public class Staff {

    private int staffId;
    private String name;
    private String role;
    private String username;
    private String password;

    public Staff(int staffId, String name, String role, String username, String password) {
        this.staffId = staffId;
        this.name = name;
        this.role = role;
        this.username = username;
        this.password = password;
    }

    public Staff(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public int getStaffId() {
        return staffId;
    }

    public String getName() {
        return name;
    }

    public String getRole() {
        return role;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}
