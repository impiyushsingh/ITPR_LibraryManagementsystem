package lms.model;
import java.sql.Timestamp;

public class Alert {
    private int alertId;
    private String alertType;
    private String message;
    private Timestamp createdAt;
    private boolean isRead;

    public Alert(int id, String type, String msg, Timestamp time, boolean read) {
        alertId = id; alertType = type; message = msg; createdAt = time; isRead = read;
    }
    public Alert(String t, String m) { alertType = t; message = m; }

    public int getAlertId() { return alertId; }
    public String getAlertType() { return alertType; }
    public String getMessage() { return message; }
}
