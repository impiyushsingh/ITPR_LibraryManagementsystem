package lms.model;
import java.time.LocalDate;

public class Member {
    private int memberId;
    private String name;
    private String email;
    private String mobile;
    private LocalDate membershipDate;
    private String status;
    private String address;

    public Member(int id, String n, String e, String m, LocalDate d, String s, String a) {
        memberId = id; name = n; email = e; mobile = m;
        membershipDate = d; status = s; address = a;
    }

    public Member(String n, String e, String m, LocalDate d, String a) {
        name = n; email = e; mobile = m; membershipDate = d;
        status = "ACTIVE"; address = a;
    }

    public int getMemberId() { return memberId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getMobile() { return mobile; }
    public LocalDate getMembershipDate() { return membershipDate; }
    public String getStatus() { return status; }
    public String getAddress() { return address; }
}
