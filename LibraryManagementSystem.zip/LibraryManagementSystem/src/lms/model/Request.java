package lms.model;

import java.time.LocalDate;

public class Request {

    private int requestId;
    private int memberId;
    private int bookId;
    private String requestType;
    private LocalDate requestDate;
    private String status;

    public Request(int requestId, int memberId, int bookId,
                   String requestType, LocalDate requestDate, String status) {
        this.requestId = requestId;
        this.memberId = memberId;
        this.bookId = bookId;
        this.requestType = requestType;
        this.requestDate = requestDate;
        this.status = status;
    }

    public Request(int memberId, int bookId, String requestType, LocalDate requestDate) {
        this.memberId = memberId;
        this.bookId = bookId;
        this.requestType = requestType;
        this.requestDate = requestDate;
        this.status = "PENDING";
    }

    public int getRequestId() {
        return requestId;
    }

    public int getMemberId() {
        return memberId;
    }

    public int getBookId() {
        return bookId;
    }

    public String getRequestType() {
        return requestType;
    }

    public LocalDate getRequestDate() {
        return requestDate;
    }

    public String getStatus() {
        return status;
    }
}
