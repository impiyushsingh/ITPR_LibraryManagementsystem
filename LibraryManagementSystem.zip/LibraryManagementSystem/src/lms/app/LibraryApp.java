package lms.app;

import lms.model.*;
import lms.service.LibraryService;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class LibraryApp {

    private static final Scanner sc = new Scanner(System.in);
    private static final LibraryService service = new LibraryService();

    public static void main(String[] args) {

        while (true) {
            System.out.println("\n==== Library Management System ====");
            System.out.println("1. Admin Login");
            System.out.println("2. Member Menu");
            System.out.println("3. Exit");
            System.out.print("Choose: ");

            int choice = readInt();

            switch (choice) {
                case 1 -> adminLogin();
                case 2 -> memberMenu();
                case 3 -> {
                    System.out.println("Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    // ========== ADMIN FLOW ==========

    private static void adminLogin() {
        System.out.print("Username: ");
        String user = sc.nextLine();
        System.out.print("Password: ");
        String pass = sc.nextLine();

        Staff staff = service.loginAdmin(user, pass);
        if (staff == null) {
            System.out.println("Login failed.");
            return;
        }

        System.out.println("Welcome, " + staff.getUsername() + " (" + staff.getRole() + ")");
        adminMenu();
    }

    private static void adminMenu() {
        while (true) {
            System.out.println("\n==== Admin Menu ====");
            System.out.println("1. Manage Books (Add / List)");
            System.out.println("2. Manage Members (Register / List)");
            System.out.println("3. View Pending Requests");
            System.out.println("4. View Reports");
            System.out.println("5. Issue Book (Direct)");
            System.out.println("6. Return Book");
            System.out.println("7. Back to Main Menu");
            System.out.print("Choose: ");

            int ch = readInt();
            switch (ch) {
                case 1 -> adminManageBooks();
                case 2 -> adminManageMembers();
                case 3 -> adminViewRequests();
                case 4 -> adminReports();
                case 5 -> adminIssueDirect();
                case 6 -> adminReturnBook();
                case 7 -> {
                    return;
                }
                default -> System.out.println("Invalid.");
            }
        }
    }

    private static void adminManageBooks() {
        System.out.println("\n1. Add Book");
        System.out.println("2. List Books");
        System.out.print("Choice: ");
        int ch = readInt();

        if (ch == 1) {
            System.out.print("Title: ");
            String title = sc.nextLine();
            System.out.print("Author ID (0 if none): ");
            int authorId = readInt();
            System.out.print("Category ID (0 if none): ");
            int catId = readInt();
            System.out.print("ISBN: ");
            String isbn = sc.nextLine();
            System.out.print("Edition: ");
            String edition = sc.nextLine();
            System.out.print("Publication Year (YYYY): ");
            int year = readInt();
            System.out.print("Rack ID (0 if none): ");
            int rackId = readInt();
            System.out.print("Total copies: ");
            int copies = readInt();

            Book b = new Book(title, authorId, catId, isbn, edition, year, rackId, copies);
            service.addBook(b);
            System.out.println("Book added.");
        } else if (ch == 2) {
            List<Book> list = service.getAllBooks();
            System.out.println("\n--- Books ---");
            for (Book b : list) {
                System.out.printf("%d) %s | ISBN: %s | Avail: %d/%d%n",
                        b.getBookId(), b.getTitle(), b.getIsbn(),
                        b.getAvailableCopies(), b.getTotalCopies());
            }
        }
    }

    private static void adminManageMembers() {
        System.out.println("\n1. Register Member");
        System.out.println("2. List Members");
        System.out.print("Choice: ");
        int ch = readInt();

        if (ch == 1) {
            System.out.print("Name: ");
            String name = sc.nextLine();
            System.out.print("Email: ");
            String email = sc.nextLine();
            System.out.print("Mobile: ");
            String mobile = sc.nextLine();
            System.out.print("Address: ");
            String address = sc.nextLine();

            Member m = new Member(name, email, mobile, LocalDate.now(), address);
            service.registerMember(m);
            System.out.println("Member registered.");
        } else if (ch == 2) {
            List<Member> list = service.getAllMembers();
            System.out.println("\n--- Members ---");
            for (Member m : list) {
                System.out.printf("%d) %s | %s | %s%n",
                        m.getMemberId(), m.getName(), m.getEmail(), m.getStatus());
            }
        }
    }

    private static void adminViewRequests() {
        List<Request> pending = service.getPendingRequests();
        if (pending.isEmpty()) {
            System.out.println("No pending requests.");
            return;
        }

        System.out.println("\n--- Pending Requests ---");
        for (Request r : pending) {
            System.out.printf("ReqID: %d | Member: %d | Book: %d | Type: %s | Date: %s | Status: %s%n",
                    r.getRequestId(), r.getMemberId(), r.getBookId(),
                    r.getRequestType(), r.getRequestDate(), r.getStatus());
        }

        System.out.print("Enter Request ID to process (0 to cancel): ");
        int id = readInt();
        if (id == 0) return;

        Request selected = null;
        for (Request r : pending) {
            if (r.getRequestId() == id) {
                selected = r;
                break;
            }
        }
        if (selected == null) {
            System.out.println("Invalid request ID.");
            return;
        }

        System.out.println("1. Approve");
        System.out.println("2. Reject");
        System.out.print("Choice: ");
        int ch = readInt();

        if (ch == 1) {
            service.approveIssueRequest(selected);
            System.out.println("Request approved.");
        } else if (ch == 2) {
            System.out.print("Reason: ");
            String reason = sc.nextLine();
            service.rejectRequest(selected.getRequestId(), selected.getMemberId(), reason);
            System.out.println("Request rejected.");
        }
    }

    private static void adminReports() {
        System.out.println("\n1. All Issues");
        System.out.println("2. Overdue Issues");
        System.out.println("3. Total Fines Collected");
        System.out.print("Choice: ");
        int ch = readInt();

        switch (ch) {
            case 1 -> {
                List<Issue> all = service.getAllIssues();
                System.out.println("\n--- All Issues ---");
                for (Issue i : all) {
                    System.out.printf("IssueID: %d | Book: %d | Member: %d | Issue: %s | Due: %s | Status: %s%n",
                            i.getIssueId(), i.getBookId(), i.getMemberId(),
                            i.getIssueDate(), i.getDueDate(), i.getStatus());
                }
            }
            case 2 -> {
                List<Issue> over = service.getOverdueIssues();
                System.out.println("\n--- Overdue Issues ---");
                for (Issue i : over) {
                    System.out.printf("IssueID: %d | Book: %d | Member: %d | Issue: %s | Due: %s%n",
                            i.getIssueId(), i.getBookId(), i.getMemberId(),
                            i.getIssueDate(), i.getDueDate());
                }
            }
            case 3 -> {
                double total = service.getTotalFinesCollected();
                System.out.println("Total fines collected (PAID): Rs " + total);
            }
        }
    }

    private static void adminIssueDirect() {
        System.out.print("Member ID: ");
        int m = readInt();
        System.out.print("Book ID: ");
        int b = readInt();

        String title = service.issueBookDirect(m, b);
        if (title != null) {
            System.out.println("Book issued: " + title);
        } else {
            System.out.println("Book not available or invalid.");
        }
    }

    private static void adminReturnBook() {
        System.out.print("Issue ID: ");
        int issueId = readInt();
        System.out.print("Member ID: ");
        int memberId = readInt();
        System.out.print("Book ID: ");
        int bookId = readInt();

        String title = service.returnBook(issueId, memberId, bookId);
        System.out.println("Book returned: " + title);
    }

    // ========== MEMBER FLOW ==========

    private static void memberMenu() {
        System.out.print("Enter your Member ID: ");
        int memberId = readInt();

        while (true) {
            System.out.println("\n==== Member Menu ====");
            System.out.println("1. Search Books");
            System.out.println("2. View My Issued Books");
            System.out.println("3. Request Book Issue");
            System.out.println("4. Request Renewal");
            System.out.println("5. Back");
            System.out.print("Choose: ");

            int ch = readInt();
            switch (ch) {
                case 1 -> memberSearchBooks();
                case 2 -> memberViewIssued(memberId);
                case 3 -> memberRequestIssue(memberId);
                case 4 -> memberRequestRenew(memberId);
                case 5 -> {
                    return;
                }
                default -> System.out.println("Invalid.");
            }
        }
    }

    private static void memberSearchBooks() {
        System.out.print("Enter keyword (title / ISBN): ");
        String key = sc.nextLine();
        List<Book> list = service.searchBooks(key);

        if (list.isEmpty()) {
            System.out.println("No books found.");
            return;
        }

        System.out.println("\n--- Search Results ---");
        for (Book b : list) {
            System.out.printf("%d) %s | ISBN: %s | Avail: %d/%d%n",
                    b.getBookId(), b.getTitle(), b.getIsbn(),
                    b.getAvailableCopies(), b.getTotalCopies());
        }
    }

    private static void memberViewIssued(int memberId) {
        List<Issue> issues = service.getIssuedBooksForMember(memberId);
        if (issues.isEmpty()) {
            System.out.println("You have no active issues.");
            return;
        }

        System.out.println("\n--- Your Issued Books ---");
        for (Issue i : issues) {
            System.out.printf("IssueID: %d | BookID: %d | Issue: %s | Due: %s%n",
                    i.getIssueId(), i.getBookId(), i.getIssueDate(), i.getDueDate());
        }
    }

    private static void memberRequestIssue(int memberId) {
        System.out.print("Enter Book ID to request: ");
        int bookId = readInt();
        service.createIssueRequest(memberId, bookId);
        System.out.println("Issue request submitted.");
    }

    private static void memberRequestRenew(int memberId) {
        System.out.print("Enter Book ID to renew: ");
        int bookId = readInt();
        service.createRenewRequest(memberId, bookId);
        System.out.println("Renew request submitted.");
    }

    // ========== UTIL ==========

    private static int readInt() {
        while (true) {
            try {
                String line = sc.nextLine();
                return Integer.parseInt(line.trim());
            } catch (Exception e) {
                System.out.print("Enter valid number: ");
            }
        }
    }
}
