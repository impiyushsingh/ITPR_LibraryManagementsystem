package lms.dao;

import lms.config.DBUtil;
import lms.model.Book;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {

    // ================= INSERT BOOK =================

    public boolean insert(Book b) {
        String sql = """
                INSERT INTO books
                (title, author_id, category_id, isbn, edition, publication_year,
                 rack_id, total_copies, available_copies, lost_copies)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, b.getTitle());
            ps.setInt(2, b.getAuthorId());
            ps.setInt(3, b.getCategoryId());
            ps.setString(4, b.getIsbn());
            ps.setString(5, b.getEdition());
            ps.setInt(6, b.getPublicationYear());
            ps.setInt(7, b.getRackId());
            ps.setInt(8, b.getTotalCopies());
            ps.setInt(9, b.getAvailableCopies());
            ps.setInt(10, b.getLostCopies());

            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("❌ BOOK INSERT FAILED");
            System.out.println("Reason: " + e.getMessage());
            return false;
        }
    }

    // ================= CHECK AVAILABILITY =================

    public boolean isAvailable(int bookId) {
        String sql = "SELECT available_copies FROM books WHERE book_id=?";
        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, bookId);
            ResultSet rs = ps.executeQuery();
            return rs.next() && rs.getInt(1) > 0;

        } catch (Exception e) {
            return false;
        }
    }

    // ================= UPDATE AVAILABILITY =================

    public void updateAvailability(int bookId, int diff) {
        String sql = "UPDATE books SET available_copies = available_copies + ? WHERE book_id = ?";

        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, diff);
            ps.setInt(2, bookId);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= GET BOOK TITLE =================

    public String getBookTitle(int bookId) {
        String sql = "SELECT title FROM books WHERE book_id=?";

        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, bookId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getString("title");

        } catch (Exception e) {
            e.printStackTrace();
        }

        return "Unknown Book";
    }

    // ================= SEARCH BOOK =================

    public List<Book> searchBooks(String keyword) {
        List<Book> list = new ArrayList<>();
        String sql = """
                SELECT * FROM books
                WHERE title LIKE ? OR isbn LIKE ?
                """;

        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            String q = "%" + keyword + "%";
            ps.setString(1, q);
            ps.setString(2, q);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(map(rs));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // ================= GET ALL BOOKS =================

    public List<Book> getAllBooks() {
        List<Book> list = new ArrayList<>();

        try (Connection c = DBUtil.getConnection();
             Statement s = c.createStatement();
             ResultSet rs = s.executeQuery("SELECT * FROM books")) {

            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // ================= MAP RESULTSET =================

    private Book map(ResultSet rs) throws SQLException {
        return new Book(
                rs.getInt("book_id"),
                rs.getString("title"),
                rs.getInt("author_id"),
                rs.getInt("category_id"),
                rs.getString("isbn"),
                rs.getString("edition"),
                rs.getInt("publication_year"),
                rs.getInt("rack_id"),
                rs.getInt("total_copies"),
                rs.getInt("available_copies"),
                rs.getInt("lost_copies")
        );
    }
}
