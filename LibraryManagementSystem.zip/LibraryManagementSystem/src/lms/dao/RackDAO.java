package lms.dao;
import lms.config.DBUtil;
import lms.model.Rack;
import java.sql.*;

public class RackDAO {
    public void insert(Rack r){
        String sql="INSERT INTO racks(rack_number,section) VALUES (?,?)";
        try(Connection c=DBUtil.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,r.getRackNumber());
            ps.setString(2,r.getSection());
            ps.executeUpdate();
        }catch(Exception e){}
    }
}
