package lms.dao;
import lms.config.DBUtil;
import lms.model.Damage;
import java.sql.*;

public class DamageDAO {
    public void insert(Damage d){
        String sql="INSERT INTO damaged_books(book_id,type,date,remarks) VALUES (?,?,?,?)";
        try(Connection c=DBUtil.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,d.getBookId());
            ps.setString(2,d.getType());
            ps.setDate(3,Date.valueOf(d.getDate()));
            ps.setString(4,d.getRemarks());
            ps.executeUpdate();
        }catch(Exception e){}
    }
}
