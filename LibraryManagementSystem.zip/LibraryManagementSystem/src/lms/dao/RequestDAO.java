package lms.dao;

import lms.config.DBUtil;
import lms.model.Request;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RequestDAO {

    public void insert(Request r) {
        String sql = "INSERT INTO book_requests(member_id,book_id,request_type,request_date,status) VALUES(?,?,?,?, 'PENDING')";
        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, r.getMemberId());
            ps.setInt(2, r.getBookId());
            ps.setString(3, r.getRequestType());
            ps.setDate(4, Date.valueOf(r.getRequestDate()));
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Request> getPendingRequests() {
        List<Request> list = new ArrayList<>();
        String sql = "SELECT * FROM book_requests WHERE status='PENDING'";

        try (Connection c = DBUtil.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new Request(
                        rs.getInt("request_id"),
                        rs.getInt("member_id"),
                        rs.getInt("book_id"),
                        rs.getString("request_type"),
                        rs.getDate("request_date").toLocalDate(),
                        rs.getString("status")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void updateStatus(int requestId, String status) {
        String sql = "UPDATE book_requests SET status=? WHERE request_id=?";
        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, status);
            ps.setInt(2, requestId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
