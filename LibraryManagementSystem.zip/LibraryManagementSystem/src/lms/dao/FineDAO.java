package lms.dao;

import lms.config.DBUtil;
import lms.model.Fine;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FineDAO {

    public void insert(Fine f) {
        String sql = "INSERT INTO fines(member_id,issue_id,amount,status) VALUES(?,?,?, 'UNPAID')";
        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, f.getMemberId());
            ps.setInt(2, f.getIssueId());
            ps.setDouble(3, f.getAmount());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public double getTotalFinesCollected() {
        String sql = "SELECT COALESCE(SUM(amount),0) FROM fines WHERE status='PAID'";
        try (Connection c = DBUtil.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            if (rs.next()) return rs.getDouble(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    public List<Fine> getFinesByMember(int memberId) {
        List<Fine> list = new ArrayList<>();
        String sql = "SELECT * FROM fines WHERE member_id=?";

        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, memberId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Fine(
                        rs.getInt("fine_id"),
                        rs.getInt("member_id"),
                        rs.getInt("issue_id"),
                        rs.getDouble("amount"),
                        rs.getString("status"),
                        rs.getDate("payment_date")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
