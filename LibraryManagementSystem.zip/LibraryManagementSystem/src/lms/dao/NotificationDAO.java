package lms.dao;
import lms.config.DBUtil;
import lms.model.Notification;
import java.sql.*;

public class NotificationDAO {
    public void insert(Notification n){
        String sql="INSERT INTO notifications(member_id,message,type,status) VALUES(?,?,?, 'UNREAD')";
        try(Connection c=DBUtil.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,n.getMemberId());
            ps.setString(2,n.getMessage());
            ps.setString(3,n.getType());
            ps.executeUpdate();
        }catch(Exception e){}
    }
}
