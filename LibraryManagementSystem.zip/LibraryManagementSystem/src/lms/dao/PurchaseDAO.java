package lms.dao;
import lms.config.DBUtil;
import lms.model.Purchase;
import java.sql.*;

public class PurchaseDAO {
    public void insert(Purchase p){
        String sql="INSERT INTO purchases(book_id,vendor_id,quantity,purchase_date,price_per_copy) VALUES (?,?,?,?,?)";
        try(Connection c=DBUtil.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,p.getBookId());
            ps.setInt(2,p.getVendorId());
            ps.setInt(3,p.getQuantity());
            ps.setDate(4,Date.valueOf(p.getPurchaseDate()));
            ps.setDouble(5,p.getPricePerCopy());
            ps.executeUpdate();
        }catch(Exception e){}
    }
}
