package lms.dao;
import lms.config.DBUtil;
import lms.model.Alert;
import java.sql.*;

public class AlertDAO {
    public void insert(Alert a){
        String sql="INSERT INTO alerts(alert_type,message) VALUES (?,?)";
        try(Connection c=DBUtil.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,a.getAlertType());
            ps.setString(2,a.getMessage());
            ps.executeUpdate();
        }catch(Exception e){}
    }
}
