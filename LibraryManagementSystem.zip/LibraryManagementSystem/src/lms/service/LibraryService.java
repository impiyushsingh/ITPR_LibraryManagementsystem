package lms.service;

import lms.dao.*;
import lms.model.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class LibraryService {

    private final BookDAO bookDAO = new BookDAO();
    private final IssueDAO issueDAO = new IssueDAO();
    private final MemberDAO memberDAO = new MemberDAO();
    private final RequestDAO requestDAO = new RequestDAO();
    private final FineDAO fineDAO = new FineDAO();
    private final NotificationDAO notificationDAO = new NotificationDAO();
    private final StaffDAO staffDAO = new StaffDAO();

    private static final int LOAN_DAYS = 14;
    private static final double FINE_PER_DAY = 5.0;

    // ======= AUTH =======

    public Staff loginAdmin(String username, String password) {
        return staffDAO.login(username, password);
    }

    // ======= ADMIN: BOOK / MEMBER MANAGEMENT =======

    public void addBook(Book book) {
        bookDAO.insert(book);
    }

    public List<Book> getAllBooks() {
        return bookDAO.getAllBooks();
    }

    public void registerMember(Member m) {
        memberDAO.insert(m);
    }

    public List<Member> getAllMembers() {
        return memberDAO.getAll();
    }

    // ======= USER: SEARCH / VIEW ISSUED =======

    public List<Book> searchBooks(String keyword) {
        return bookDAO.searchBooks(keyword);
    }

    public List<Issue> getIssuedBooksForMember(int memberId) {
        return issueDAO.getIssuesByMember(memberId);
    }

    // ======= REQUESTS (ISSUE / RENEW) =======

    public void createIssueRequest(int memberId, int bookId) {
        Request req = new Request(memberId, bookId, "ISSUE", LocalDate.now());
        requestDAO.insert(req);
    }

    public void createRenewRequest(int memberId, int bookId) {
        Request req = new Request(memberId, bookId, "RENEW", LocalDate.now());
        requestDAO.insert(req);
    }

    public List<Request> getPendingRequests() {
        return requestDAO.getPendingRequests();
    }

    public void approveIssueRequest(Request req) {
        // only ISSUE handled simply here
        if (!"ISSUE".equalsIgnoreCase(req.getRequestType())) return;

        // Check availability
        if (!bookDAO.isAvailable(req.getBookId())) {
            requestDAO.updateStatus(req.getRequestId(), "REJECTED");
            notificationDAO.insert(new Notification(req.getMemberId(),
                    "Your request " + req.getRequestId() + " was rejected (no stock).",
                    "Request Approval"));
            return;
        }

        LocalDate issue = LocalDate.now();
        LocalDate due = issue.plusDays(LOAN_DAYS);

        issueDAO.insert(new Issue(req.getBookId(), req.getMemberId(), issue, due));
        bookDAO.updateAvailability(req.getBookId(), -1);
        requestDAO.updateStatus(req.getRequestId(), "APPROVED");

        notificationDAO.insert(new Notification(req.getMemberId(),
                "Your book issue request " + req.getRequestId() + " has been approved.",
                "Request Approval"));
    }

    public void rejectRequest(int requestId, int memberId, String reason) {
        requestDAO.updateStatus(requestId, "REJECTED");
        notificationDAO.insert(new Notification(memberId,
                "Your request " + requestId + " was rejected: " + reason,
                "Request Approval"));
    }

    // ======= ISSUE / RETURN (TRANSACTION MODULE) =======

    public String issueBookDirect(int memberId, int bookId) {
        if (!bookDAO.isAvailable(bookId)) return null;

        LocalDate issue = LocalDate.now();
        LocalDate due = issue.plusDays(LOAN_DAYS);
        issueDAO.insert(new Issue(bookId, memberId, issue, due));
        bookDAO.updateAvailability(bookId, -1);

        return bookDAO.getBookTitle(bookId);
    }

    public String returnBook(int issueId, int memberId, int bookId) {
        // Load issue to compute lateness
        List<Issue> all = issueDAO.getAllIssues();
        Issue match = null;
        for (Issue i : all) {
            if (i.getIssueId() == issueId) {
                match = i;
                break;
            }
        }
        LocalDate today = LocalDate.now();
        LocalDate due = (match != null ? match.getDueDate() : today);

        long lateDays = ChronoUnit.DAYS.between(due, today);
        if (lateDays < 0) lateDays = 0;

        issueDAO.markReturned(issueId, today);
        bookDAO.updateAvailability(bookId, 1);

        if (lateDays > 0) {
            double fineAmt = lateDays * FINE_PER_DAY;
            fineDAO.insert(new Fine(memberId, issueId, fineAmt));
            notificationDAO.insert(new Notification(memberId,
                    "You have a fine of Rs " + fineAmt + " for late return (issue #" + issueId + ")",
                    "Fine"));
        }

        return bookDAO.getBookTitle(bookId);
    }

    // ======= REPORTS =======

    public List<Issue> getAllIssues() {
        return issueDAO.getAllIssues();
    }

    public List<Issue> getOverdueIssues() {
        return issueDAO.getOverdueIssues();
    }

    public double getTotalFinesCollected() {
        return fineDAO.getTotalFinesCollected();
    }
}
